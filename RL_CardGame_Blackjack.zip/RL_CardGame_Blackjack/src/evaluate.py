import gymnasium as gym
import torch
import time
from agent import BlackjackAgent


CYAN = '\033[96m'
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
RESET = '\033[0m'
BOLD = '\033[1m'
GREEN_BG = '\033[42m\033[97m'

def run_evaluation(env, agent, episodes, is_random=False):
    wins, draws, losses = 0, 0, 0
    
    for _ in range(episodes):
        state, _ = env.reset()
        done = False
        while not done:
            if is_random:
                
                action = env.action_space.sample()
            else:
                
                action = agent.act(state, eps=0.0)
                
            state, reward, done, truncated, _ = env.step(action)
            
        if reward > 0:
            wins += 1
        elif reward == 0:
            draws += 1
        else:
            losses += 1
            
    win_rate = (wins / episodes) * 100
    draw_rate = (draws / episodes) * 100
    loss_rate = (losses / episodes) * 100
    
    return win_rate, draw_rate, loss_rate

def main():
    episodes = 100000
    env = gym.make("Blackjack-v1")
    
    print(f"{CYAN}{BOLD}>>>  Starting Scientific Evaluation ({episodes:,} Episodes)...{RESET}\n")
    

    print(f"{YELLOW}>>> Evaluating Random Agent...{RESET}")
    start_time = time.time()
    rand_win, rand_draw, rand_loss = run_evaluation(env, None, episodes, is_random=True)
    rand_time = time.time() - start_time

    print(f"{YELLOW}>>> Evaluating Ultimate Trained Agent...{RESET}")
    agent = BlackjackAgent()
    agent.qnetwork_local.load_state_dict(torch.load('../models/blackjack_max_dqn.pth'))
    agent.qnetwork_local.eval()
    
    start_time = time.time()
    train_win, train_draw, train_loss = run_evaluation(env, agent, episodes, is_random=False)
    train_time = time.time() - start_time
    
    print(f"\n{BOLD}===================================================={RESET}")
    print(f"{BOLD} SCIENTIFIC EVALUATION RESULTS (100,000 Games){RESET}")
    print(f"{BOLD}===================================================={RESET}\n")
    
    print(f" {BOLD}Random Agent Performance:{RESET} (Time: {rand_time:.1f}s)")
    print(f"   Win Rate:  {RED}{rand_win:.2f}%{RESET}")
    print(f"   Draw Rate: {YELLOW}{rand_draw:.2f}%{RESET}")
    print(f"   Loss Rate: {RED}{rand_loss:.2f}%{RESET}\n")
    
    print(f" {BOLD}Trained DQN Agent Performance:{RESET} (Time: {train_time:.1f}s)")
    print(f"   Win Rate:  {GREEN}{train_win:.2f}%{RESET}")
    print(f"   Draw Rate: {YELLOW}{train_draw:.2f}%{RESET}")
    print(f"   Loss Rate: {GREEN}{train_loss:.2f}%{RESET}\n")
    
    improvement = train_win - rand_win
    print(f"{BOLD} AI Improvement over Random: {GREEN}+{improvement:.2f}%{RESET}")
    
    if train_win >= 41.0:
        print(f"\n{GREEN_BG}  VERDICT: MASTER LEVEL ACHIEVED!  {RESET}")
        print("Your AI has reached the mathematical limit of Blackjack optimal strategy!")
    
    env.close()

if __name__ == "__main__":
    main()
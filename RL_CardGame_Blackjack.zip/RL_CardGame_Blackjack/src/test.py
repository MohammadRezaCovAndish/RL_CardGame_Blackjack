import gymnasium as gym
import torch
import time
from agent import BlackjackAgent


GREEN_BG = '\033[42m\033[97m'
RED_BG = '\033[41m\033[97m'
YELLOW_BG = '\033[43m\033[90m'
RESET = '\033[0m'
BOLD = '\033[1m'

def test_blackjack(episodes=40):
    env = gym.make("Blackjack-v1", render_mode="human")
    agent = BlackjackAgent()
    
    model_path = '../models/blackjack_max_dqn.pth'
    agent.qnetwork_local.load_state_dict(torch.load(model_path))
    agent.qnetwork_local.eval()
    
    print(f"{BOLD}>>>  Testing Ultimate Agent for {episodes} Episodes...{RESET}\n")
    
    wins = 0
    draws = 0
    losses = 0

    for i in range(1, episodes + 1):
        state, _ = env.reset()
        done = False
        
        while not done:
            action = agent.act(state, eps=0.0) 
            state, reward, done, truncated, _ = env.step(action)
            time.sleep(1) 
            
        if reward > 0:
            wins += 1
            result_str = f"{GREEN_BG} WIN  {RESET}"
        elif reward == 0:
            draws += 1
            result_str = f"{YELLOW_BG} DRAW  {RESET}"
        else:
            losses += 1
            result_str = f"{RED_BG} LOSS  {RESET}"
            
        print(f"Test Episode {i:02d}: {result_str}")
        time.sleep(1.5) 
    win_rate = (wins / episodes) * 100
    
    print(f"\n{BOLD}--- Final Performance ---{RESET}")
    print(f"Total Games: {episodes}")
    print(f"Wins: {wins} | Draws: {draws} | Losses: {losses}")
    print(f"Win Rate: {win_rate:.1f}%")
    
    env.close()

if __name__ == "__main__":
    test_blackjack()
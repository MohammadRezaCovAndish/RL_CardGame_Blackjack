import gymnasium as gym
import torch
import os
import time
from agent import BlackjackAgent


CYAN = '\033[96m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
RESET = '\033[0m'

def train_blackjack(n_episodes=500000):
    agent = BlackjackAgent()
    
   
    print(f"{CYAN}>>> Rendering first 40 episodes for observation...{RESET}")
    env_render = gym.make("Blackjack-v1", render_mode="human")
    
    for i_episode in range(1, 41):
        state, _ = env_render.reset()
        done = False
        while not done:
            action = agent.act(state, agent.epsilon)
            next_state, reward, done, truncated, _ = env_render.step(action)
            agent.step(state, action, reward, next_state, done)
            state = next_state
            time.sleep(0.5) 
        print(f"Rendered Episode {i_episode}/40 finished.")
    
    env_render.close()
    
   
    print(f"\n{YELLOW}>>> Starting Maximum Training (500,000 episodes)... Please wait.{RESET}")
    env = gym.make("Blackjack-v1")
    
    for i_episode in range(41, n_episodes + 1):
        state, _ = env.reset()
        done = False
        while not done:
            action = agent.act(state, agent.epsilon)
            next_state, reward, done, truncated, _ = env.step(action)
            agent.step(state, action, reward, next_state, done)
            state = next_state
            
        agent.epsilon = max(agent.epsilon_min, agent.epsilon_decay * agent.epsilon)
        
       
        if i_episode % 10000 == 0:
            print(f"Episode {i_episode}/{n_episodes} | Epsilon: {agent.epsilon:.4f}")
            
    os.makedirs('../models', exist_ok=True)
    torch.save(agent.qnetwork_local.state_dict(), '../models/blackjack_max_dqn.pth')
    print(f"\n{GREEN}>>> Training complete! Ultimate Model saved to '../models/blackjack_max_dqn.pth'{RESET}")
    env.close()

if __name__ == "__main__":
    train_blackjack()